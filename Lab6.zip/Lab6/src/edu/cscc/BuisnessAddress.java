package edu.cscc;

public class BuisnessAddress extends Address
{
    private String buisnessName;
    private String address2;

    public BuisnessAddress(String streetAddress, String city, String state, String zip, String buisnessName, String address2)
    {
        super(streetAddress, city, state, zip);
        this.buisnessName = buisnessName;
        this.address2 = address2;
    }

    public String getBuisnessName()
    {
        return buisnessName;
    }

    public void setBuisnessName(String buisnessName)
    {
        this.buisnessName = buisnessName;
    }

    public String getAddress2()
    {
        return address2;
    }

    public void setAddress2(String address2)
    {
        this.address2 = address2;
    }

    @Override
    public void printLabel() {
        System.out.println(getBuisnessName());

        if (getAddress2() == null || getAddress2() == "")
        {

        } else
            {
                System.out.println(getAddress2());
            }

        if(getStreetAddress() == null || getStreetAddress() == "")
        {

        }else
            {
                System.out.println(getStreetAddress());
            }
        System.out.println(getCity() + ", " + getState() + "  " + getZip());
    }
}
