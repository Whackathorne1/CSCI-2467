package edu.cscc;

public class PersonAddress extends Address
{
    private String PersonName;

    public PersonAddress(String streetAddress, String city, String state, String zip, String personName)
    {
        super(streetAddress, city, state, zip);
        PersonName = personName;
    }

    public String getPersonName()
    {
        return PersonName;
    }

    public void setPersonName(String personName)
    {
        PersonName = personName;
    }



    @Override
    public void printLabel()
    {
        System.out.println(getPersonName() + "\n" + getStreetAddress() + "\n" +  getCity() + ", " + getState() + "  " + getZip() );
    }
}
