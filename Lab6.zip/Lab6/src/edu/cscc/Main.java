package edu.cscc;

public class Main {

    public static void main(String[] args) {
	    Address[] addressList = new Address[6];

	    addressList[0] = new BuisnessAddress("281 W Lane Ave", "Columbus", "OH", "43210", "Ohio State University", null);
        addressList[1] = new BuisnessAddress(null, "Columbus", "OH", "43201", "AEP",  "P.O. Box 2075");
        addressList[2] = new BuisnessAddress("4195 Lincoln Park Ct.", "Columbus", "OH", "43228", "Bulsho Coffee Shop",  null);

        addressList[3]= new PersonAddress("1200 N. Fourth St.", "Worthington", "OH",  "43217", "Saul Course");
        addressList[4] = new PersonAddress("207 Main St.", "Reynoldsburg", "OH",  "43211", "Hero Ehrmentrau");
        addressList[5] = new PersonAddress("2091 Elm St.", "Pickerington", "OH",  "43191", "Gustavo Chegg");


	    for (Address address : addressList) {
	        address.printLabel();
            System.out.println("====================");
        }
    }
}
