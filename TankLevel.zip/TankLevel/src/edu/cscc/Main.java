package edu.cscc;

public class Main {

    public static void main(String[] args) {

        HoldingTank tank = new HoldingTank(400, 1000);
        tank.print();
        tank.add(400);
        tank.drain(150);
        tank.print();
        tank.add(800);
        tank.drain(50);
        tank.print();
        tank.drain(1200);
        tank.add(400);
        tank.drain(75);
        tank.print();

    }
}


