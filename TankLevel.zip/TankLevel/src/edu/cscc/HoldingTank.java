package edu.cscc;

public class HoldingTank {
    private int current;
    private int maxCapacity;

    public HoldingTank(int current, int maxCapacity) {
        this.current = current;
        this.maxCapacity = maxCapacity;
        if (current > maxCapacity) current = maxCapacity;
    }

    public int getCurrent() {
        return current;
    }

    public int maxCapacity() {
        return maxCapacity;
    }

    public void add(int volume) {
        this.current += volume;
        if (current > maxCapacity) current = maxCapacity;
    }

    public void drain(int volume) {
        this.current -= volume;
        if (current < 0) current = 0;
    }

    public void print(){
        System.out.println("The tank volume is "+getCurrent()+" gallons.");
    }
}











