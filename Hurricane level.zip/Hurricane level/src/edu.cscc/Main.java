package edu.cscc;

import java.util.Scanner;

//TODO - Wyatt Hackathorne, 9/15/20, Hurricane Wind Scale
public class Main {

    public static Scanner input = new Scanner(System.in);

    public static void main(String[] args) {
        int speed;
        String classification;

        System.out.print("Please input hurricane wind speed");
        speed = input.nextInt();

        if ((speed <= 0) && (speed >= 38)) {
            classification = "Not on scale";
        } else if ((speed >= 39) && (speed <= 73)) {
            classification = "This is a tropical storm";
        } else if ((speed >= 74) && (speed <= 95)) {
            classification = "This is a category one hurricane";
        } else if ((speed >= 96) && (speed <= 110)) {
            classification = "This is a category two hurricane";
        } else if ((speed >= 111) && (speed <= 129)) {
            classification = "This is a category three hurricane";
        } else if ((speed >= 130) && (speed <= 156)) {
            classification = "This is a category four hurricane";
        } else if (speed >= 157) {
            classification = "This is a category five hurricane";
        }

        if (classifcation == classification) {
            System.out.print("Result: " + classification);
        } else {
            System.out.println("Error");

        }
    }
}









